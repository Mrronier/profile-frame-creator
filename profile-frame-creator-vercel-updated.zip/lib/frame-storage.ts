import { del, list, put } from "@vercel/blob";

const ACTIVE_FRAME_PATH = "profile-frame/active.png";

export type ActiveFrame = {
  url: string;
  uploadedAt: Date | null;
  size: number | null;
  managed: boolean;
};

export function storageIsConfigured() {
  return Boolean(process.env.BLOB_READ_WRITE_TOKEN || process.env.BLOB_STORE_ID);
}

export async function getActiveFrame(): Promise<ActiveFrame | null> {
  if (storageIsConfigured()) {
    const result = await list({ prefix: ACTIVE_FRAME_PATH, limit: 5 });
    const blob = result.blobs.find((item) => item.pathname === ACTIVE_FRAME_PATH);
    if (blob) {
      return {
        url: blob.url,
        uploadedAt: blob.uploadedAt,
        size: blob.size,
        managed: true,
      };
    }
  }

  const fallbackUrl = process.env.NEXT_PUBLIC_DEFAULT_FRAME_URL;
  return fallbackUrl
    ? { url: fallbackUrl, uploadedAt: null, size: null, managed: false }
    : null;
}

export async function saveActiveFrame(file: File) {
  if (!storageIsConfigured()) throw new Error("Frame storage is not configured.");
  return put(ACTIVE_FRAME_PATH, file, {
    access: "public",
    addRandomSuffix: false,
    allowOverwrite: true,
    contentType: "image/png",
    cacheControlMaxAge: 60,
    maximumSizeInBytes: 8 * 1024 * 1024,
  });
}

export async function deleteActiveFrame() {
  if (!storageIsConfigured()) throw new Error("Frame storage is not configured.");
  await del(ACTIVE_FRAME_PATH);
}
