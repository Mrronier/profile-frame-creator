import { createHmac, timingSafeEqual } from "node:crypto";

export const ADMIN_COOKIE = "profile_frame_admin";
const SESSION_DURATION_MS = 12 * 60 * 60 * 1000;

function secret() {
  return process.env.ADMIN_SESSION_SECRET || "";
}

function sign(value: string) {
  return createHmac("sha256", secret()).update(value).digest("base64url");
}

function safeEqual(left: string, right: string) {
  const leftBuffer = Buffer.from(left);
  const rightBuffer = Buffer.from(right);
  return leftBuffer.length === rightBuffer.length && timingSafeEqual(leftBuffer, rightBuffer);
}

export function authIsConfigured() {
  return Boolean(process.env.ADMIN_PASSWORD && process.env.ADMIN_SESSION_SECRET);
}

export function verifyAdminPassword(password: string) {
  const expected = process.env.ADMIN_PASSWORD || "";
  if (!expected || !secret()) return false;
  return safeEqual(sign(password), sign(expected));
}

export function createSessionToken() {
  const expiresAt = String(Date.now() + SESSION_DURATION_MS);
  return `${expiresAt}.${sign(expiresAt)}`;
}

export function verifySessionToken(token?: string | null) {
  if (!token || !secret()) return false;
  const [expiresAt, signature, ...rest] = token.split(".");
  if (!expiresAt || !signature || rest.length || Number(expiresAt) < Date.now()) return false;
  return safeEqual(signature, sign(expiresAt));
}

export function sessionFromCookieHeader(cookieHeader?: string | null) {
  const token = cookieHeader
    ?.split(";")
    .map((part) => part.trim())
    .find((part) => part.startsWith(`${ADMIN_COOKIE}=`))
    ?.slice(ADMIN_COOKIE.length + 1);
  return verifySessionToken(token);
}
