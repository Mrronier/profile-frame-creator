import { NextResponse } from "next/server";
import { sessionFromCookieHeader } from "@/lib/admin-session";
import { deleteActiveFrame, saveActiveFrame, storageIsConfigured } from "@/lib/frame-storage";

export const runtime = "nodejs";
const MAX_FRAME_SIZE = 8 * 1024 * 1024;

function authorized(request: Request) {
  return sessionFromCookieHeader(request.headers.get("cookie"));
}

export async function POST(request: Request) {
  if (!authorized(request)) return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  if (!storageIsConfigured()) {
    return NextResponse.json({ error: "Connect a Vercel Blob store before uploading." }, { status: 503 });
  }

  const formData = await request.formData();
  const file = formData.get("frame");
  if (!(file instanceof File)) {
    return NextResponse.json({ error: "Choose a PNG frame to upload." }, { status: 400 });
  }
  if (file.type !== "image/png") {
    return NextResponse.json({ error: "The frame must be a transparent PNG." }, { status: 400 });
  }
  if (file.size > MAX_FRAME_SIZE) {
    return NextResponse.json({ error: "The frame must be smaller than 8 MB." }, { status: 400 });
  }

  await saveActiveFrame(file);
  return NextResponse.json({ ok: true });
}

export async function DELETE(request: Request) {
  if (!authorized(request)) return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
  if (!storageIsConfigured()) {
    return NextResponse.json({ error: "Frame storage is not configured." }, { status: 503 });
  }
  await deleteActiveFrame();
  return NextResponse.json({ ok: true });
}
