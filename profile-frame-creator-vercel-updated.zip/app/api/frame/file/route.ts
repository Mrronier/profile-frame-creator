import { NextResponse } from "next/server";
import { getActiveFrame } from "@/lib/frame-storage";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  const frame = await getActiveFrame().catch(() => null);
  if (!frame) return new NextResponse("Frame not found", { status: 404 });

  const upstream = await fetch(frame.url, { cache: "no-store" });
  if (!upstream.ok) return new NextResponse("Frame not found", { status: 404 });

  return new NextResponse(upstream.body, {
    headers: {
      "Content-Type": upstream.headers.get("content-type") || "image/png",
      "Cache-Control": "public, max-age=60, s-maxage=60, stale-while-revalidate=300",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
