import { NextResponse } from "next/server";
import { getActiveFrame, storageIsConfigured } from "@/lib/frame-storage";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function GET() {
  try {
    const frame = await getActiveFrame();
    const version = frame?.uploadedAt?.getTime() || "default";
    return NextResponse.json(
      {
        configured: storageIsConfigured() || Boolean(process.env.NEXT_PUBLIC_DEFAULT_FRAME_URL),
        frame: frame
          ? {
              url: `/api/frame/file?v=${version}`,
              uploadedAt: frame.uploadedAt?.toISOString() || null,
            }
          : null,
      },
      { headers: { "Cache-Control": "no-store" } },
    );
  } catch {
    return NextResponse.json({ configured: false, frame: null }, { status: 503 });
  }
}
