import type { Metadata } from "next";
import { cookies } from "next/headers";
import { AdminFrameManager } from "@/components/admin-frame-manager";
import { AdminLogin } from "@/components/admin-login";
import { ADMIN_COOKIE, authIsConfigured, verifySessionToken } from "@/lib/admin-session";
import { getActiveFrame, storageIsConfigured } from "@/lib/frame-storage";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Frame Admin | Profile Frame Creator",
  robots: { index: false, follow: false },
};

export default async function AdminPage() {
  const cookieStore = await cookies();
  const authenticated = verifySessionToken(cookieStore.get(ADMIN_COOKIE)?.value);

  if (!authenticated) {
    return <AdminLogin configured={authIsConfigured()} />;
  }

  const activeFrame = await getActiveFrame().catch(() => null);
  return (
    <AdminFrameManager
      storageConfigured={storageIsConfigured()}
      initialFrame={
        activeFrame
          ? {
              url: `/api/frame/file?v=${activeFrame.uploadedAt?.getTime() || "default"}`,
              uploadedAt: activeFrame.uploadedAt?.toISOString() || null,
              size: activeFrame.size,
              managed: activeFrame.managed,
            }
          : null
      }
    />
  );
}
