import { ProfileFrameEditor } from "@/components/profile-frame-editor";
import Link from "next/link";

export default function Home() {
  return (
    <main className="site-shell">
      <header className="site-header" aria-label="Profile Frame Creator">
        <Link className="brand" href="/" aria-label="Profile Frame Creator home">
          <span className="brand-mark" aria-hidden="true">
            <span />
          </span>
          <span>Profile Frame Creator</span>
        </Link>
        <p className="privacy-pill">
          <span aria-hidden="true">●</span> Your photo stays private
        </p>
      </header>

      <section className="intro">
        <p className="eyebrow">A better profile picture in minutes</p>
        <h1>Create your profile frame</h1>
        <p>
          Upload your photo, make it fit perfectly, and download a polished
          profile picture ready to share.
        </p>
      </section>

      <ProfileFrameEditor />

      <footer className="site-footer">
        <p>Your photo is processed only in this browser and is never uploaded.</p>
        <Link href="/admin">Admin</Link>
      </footer>
    </main>
  );
}
