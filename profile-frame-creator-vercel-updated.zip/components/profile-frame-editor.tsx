"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Cropper, { type Area, type Point } from "react-easy-crop";
import {
  Check,
  Download,
  ImagePlus,
  LoaderCircle,
  Minus,
  Plus,
  RefreshCcw,
  RotateCcw,
  RotateCw,
  ShieldCheck,
  Upload,
  ZoomIn,
} from "lucide-react";

const MAX_FILE_SIZE = 20 * 1024 * 1024;
const EXPORT_SIZE = 1080;
const ACCEPTED_TYPES = ["image/jpeg", "image/png", "image/webp", "image/heic", "image/heif"];

type FrameResponse = {
  frame: null | { url: string; uploadedAt?: string };
  configured: boolean;
};

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("This image could not be loaded."));
    image.src = src;
  });
}

function rotatedBounds(width: number, height: number, rotation: number) {
  const radians = (rotation * Math.PI) / 180;
  return {
    width: Math.abs(Math.cos(radians) * width) + Math.abs(Math.sin(radians) * height),
    height: Math.abs(Math.sin(radians) * width) + Math.abs(Math.cos(radians) * height),
  };
}

async function renderDownload(
  photoUrl: string,
  frameUrl: string,
  cropPixels: Area,
  rotation: number,
) {
  const [photo, frame] = await Promise.all([loadImage(photoUrl), loadImage(frameUrl)]);
  const bounds = rotatedBounds(photo.naturalWidth, photo.naturalHeight, rotation);
  const sourceCanvas = document.createElement("canvas");
  sourceCanvas.width = Math.ceil(bounds.width);
  sourceCanvas.height = Math.ceil(bounds.height);

  const sourceContext = sourceCanvas.getContext("2d", { alpha: true });
  if (!sourceContext) throw new Error("Your browser could not prepare the image.");

  sourceContext.translate(sourceCanvas.width / 2, sourceCanvas.height / 2);
  sourceContext.rotate((rotation * Math.PI) / 180);
  sourceContext.translate(-photo.naturalWidth / 2, -photo.naturalHeight / 2);
  sourceContext.drawImage(photo, 0, 0);

  const outputCanvas = document.createElement("canvas");
  outputCanvas.width = EXPORT_SIZE;
  outputCanvas.height = EXPORT_SIZE;
  const outputContext = outputCanvas.getContext("2d", { alpha: true });
  if (!outputContext) throw new Error("Your browser could not prepare the download.");

  outputContext.imageSmoothingEnabled = true;
  outputContext.imageSmoothingQuality = "high";
  outputContext.drawImage(
    sourceCanvas,
    cropPixels.x,
    cropPixels.y,
    cropPixels.width,
    cropPixels.height,
    0,
    0,
    EXPORT_SIZE,
    EXPORT_SIZE,
  );
  outputContext.drawImage(frame, 0, 0, EXPORT_SIZE, EXPORT_SIZE);

  return new Promise<Blob>((resolve, reject) => {
    outputCanvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error("The PNG could not be created."))),
      "image/png",
      1,
    );
  });
}

async function preparePhoto(file: File): Promise<Blob> {
  const extension = file.name.split(".").pop()?.toLowerCase();
  const isHeic = ["heic", "heif"].includes(extension || "") || /heic|heif/.test(file.type);

  if (!isHeic) return file;

  const { default: heic2any } = await import("heic2any");
  const converted = await heic2any({ blob: file, toType: "image/jpeg", quality: 0.92 });
  return Array.isArray(converted) ? converted[0] : converted;
}

export function ProfileFrameEditor() {
  const inputRef = useRef<HTMLInputElement>(null);
  const objectUrlRef = useRef<string | null>(null);
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [frameUrl, setFrameUrl] = useState<string | null>(null);
  const [frameLoading, setFrameLoading] = useState(true);
  const [frameConfigured, setFrameConfigured] = useState(true);
  const [crop, setCrop] = useState<Point>({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [cropPixels, setCropPixels] = useState<Area | null>(null);
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState<"photo" | "download" | null>(null);
  const [complete, setComplete] = useState(false);

  useEffect(() => {
    let active = true;
    fetch("/api/frame", { cache: "no-store" })
      .then(async (response) => {
        if (!response.ok) throw new Error("Frame unavailable");
        return (await response.json()) as FrameResponse;
      })
      .then((data) => {
        if (!active) return;
        setFrameConfigured(data.configured);
        setFrameUrl(data.frame?.url || null);
      })
      .catch(() => {
        if (active) {
          setFrameConfigured(false);
          setFrameUrl(null);
        }
      })
      .finally(() => active && setFrameLoading(false));

    return () => {
      active = false;
      if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
    };
  }, []);

  const resetAdjustments = useCallback(() => {
    setCrop({ x: 0, y: 0 });
    setZoom(1);
    setRotation(0);
    setComplete(false);
  }, []);

  const handleFile = async (file?: File) => {
    if (!file) return;
    setMessage(null);
    setComplete(false);

    const extension = file.name.split(".").pop()?.toLowerCase();
    const supportedExtension = ["jpg", "jpeg", "png", "webp", "heic", "heif"].includes(
      extension || "",
    );
    if (!ACCEPTED_TYPES.includes(file.type) && !supportedExtension) {
      setMessage("Please choose a JPG, PNG, WebP or HEIC photo.");
      return;
    }
    if (file.size > MAX_FILE_SIZE) {
      setMessage("That photo is too large. Please choose one smaller than 20 MB.");
      return;
    }

    try {
      setBusy("photo");
      const prepared = await preparePhoto(file);
      const nextUrl = URL.createObjectURL(prepared);
      await loadImage(nextUrl);
      if (objectUrlRef.current) URL.revokeObjectURL(objectUrlRef.current);
      objectUrlRef.current = nextUrl;
      setPhotoUrl(nextUrl);
      resetAdjustments();
    } catch {
      setMessage("We could not read that photo. Please try a different image.");
    } finally {
      setBusy(null);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const handleDownload = async () => {
    if (!photoUrl || !frameUrl || !cropPixels) return;
    setMessage(null);
    setComplete(false);
    try {
      setBusy("download");
      const blob = await renderDownload(photoUrl, frameUrl, cropPixels, rotation);
      const downloadUrl = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = downloadUrl;
      link.download = "profile-frame.png";
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(downloadUrl), 30_000);
      setComplete(true);
    } catch {
      setMessage("The download could not start. Please try again in a modern browser.");
    } finally {
      setBusy(null);
    }
  };

  return (
    <section className="creator-card" aria-label="Profile picture editor">
      <div className="preview-column">
        <div className="preview-heading">
          <div>
            <span className="step-label">Step 1</span>
            <h2>Your photo</h2>
          </div>
          {photoUrl && (
            <button className="text-button" type="button" onClick={() => inputRef.current?.click()}>
              <ImagePlus size={17} /> Change photo
            </button>
          )}
        </div>

        <div className="canvas-wrap">
          {frameLoading ? (
            <div className="empty-state" aria-live="polite">
              <LoaderCircle className="spin" size={30} />
              <p>Preparing your frame…</p>
            </div>
          ) : !frameUrl ? (
            <div className="empty-state frame-missing" role="status">
              <span className="empty-icon"><ShieldCheck size={30} /></span>
              <h3>Frame coming soon</h3>
              <p>The profile frame has not been added by the administrator yet.</p>
            </div>
          ) : photoUrl ? (
            <div className="crop-stage">
              <Cropper
                image={photoUrl}
                crop={crop}
                zoom={zoom}
                rotation={rotation}
                aspect={1}
                minZoom={1}
                maxZoom={4}
                showGrid={false}
                zoomWithScroll
                onCropChange={setCrop}
                onZoomChange={setZoom}
                onRotationChange={setRotation}
                onCropComplete={(_, pixels) => setCropPixels(pixels)}
                style={{ containerStyle: { background: "#e7ebe7" } }}
              />
              {/* The admin-owned frame is always fixed above the visitor photo. */}
              {/* Dynamic frame URLs and canvas export require a native image element. */}
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img className="frame-overlay" src={frameUrl} alt="Active profile frame" draggable={false} />
              <span className="drag-hint">Drag or pinch to adjust</span>
            </div>
          ) : (
            <>
              {/* Dynamic frame URLs and canvas export require a native image element. */}
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img className="empty-frame-preview" src={frameUrl} alt="Profile frame preview" draggable={false} />
              <button
                className="upload-dropzone"
                type="button"
                onClick={() => inputRef.current?.click()}
                disabled={!frameConfigured || busy === "photo"}
              >
                <span className="upload-icon">
                  {busy === "photo" ? <LoaderCircle className="spin" /> : <Upload />}
                </span>
                <strong>{busy === "photo" ? "Preparing your photo…" : "Upload your photo"}</strong>
                <span>JPG, PNG, WebP or HEIC · Up to 20 MB</span>
                <small>Choose photo</small>
              </button>
            </>
          )}
        </div>

        <input
          ref={inputRef}
          className="visually-hidden"
          type="file"
          accept="image/jpeg,image/png,image/webp,image/heic,image/heif,.heic,.heif"
          onChange={(event) => void handleFile(event.target.files?.[0])}
          aria-label="Upload your profile photo"
        />

        <div className="save-area">
          {message && <p className="alert error-alert" role="alert">{message}</p>}
          {complete && (
            <p className="alert success-alert" role="status">
              <Check size={18} /> Your profile picture has been saved.
            </p>
          )}
          <button
            className="download-button"
            type="button"
            onClick={() => void handleDownload()}
            disabled={!photoUrl || !frameUrl || busy === "download"}
          >
            {busy === "download" ? <LoaderCircle className="spin" size={21} /> : <Download size={21} />}
            {busy === "download" ? "Creating your PNG…" : "Save to device"}
          </button>
          <p className="download-detail">High-quality PNG · 1080 × 1080 px</p>
        </div>

        <div className="privacy-note">
          <ShieldCheck size={17} />
          <span><strong>Private by design.</strong> Your photo never leaves this device.</span>
        </div>
      </div>

      <div className={`controls-column ${!photoUrl ? "controls-disabled" : ""}`}>
        <div className="controls-heading">
          <span className="step-label">Step 2</span>
          <h2>Adjust and download</h2>
          <p>Move, zoom, or rotate until your photo sits perfectly inside the frame.</p>
        </div>

        <fieldset disabled={!photoUrl}>
          <legend className="visually-hidden">Photo adjustment controls</legend>

          <div className="control-group">
            <label htmlFor="zoom"><ZoomIn size={18} /> Zoom</label>
            <div className="slider-row">
              <button type="button" aria-label="Zoom out" onClick={() => setZoom((value) => Math.max(1, value - 0.1))}>
                <Minus size={17} />
              </button>
              <input
                id="zoom"
                type="range"
                min="1"
                max="4"
                step="0.01"
                value={zoom}
                onChange={(event) => setZoom(Number(event.target.value))}
              />
              <button type="button" aria-label="Zoom in" onClick={() => setZoom((value) => Math.min(4, value + 0.1))}>
                <Plus size={17} />
              </button>
            </div>
          </div>

          <div className="control-group">
            <label htmlFor="rotation"><RotateCw size={18} /> Rotation</label>
            <div className="rotate-buttons">
              <button type="button" onClick={() => setRotation((value) => value - 90)}>
                <RotateCcw size={18} /> Rotate left
              </button>
              <button type="button" onClick={() => setRotation((value) => value + 90)}>
                <RotateCw size={18} /> Rotate right
              </button>
            </div>
            <input
              id="rotation"
              className="rotation-slider"
              type="range"
              min="-180"
              max="180"
              step="1"
              value={Math.max(-180, Math.min(180, rotation))}
              onChange={(event) => setRotation(Number(event.target.value))}
            />
          </div>

          <button className="reset-button" type="button" onClick={resetAdjustments}>
            <RefreshCcw size={17} /> Reset adjustments
          </button>
        </fieldset>

      </div>
    </section>
  );
}
