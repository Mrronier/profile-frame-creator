"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  AlertTriangle,
  Check,
  ExternalLink,
  ImageUp,
  LoaderCircle,
  LogOut,
  RefreshCcw,
  ShieldCheck,
  Trash2,
} from "lucide-react";

type FrameInfo = {
  url: string;
  uploadedAt: string | null;
  size: number | null;
  managed: boolean;
};

async function inspectPng(file: File) {
  const bitmap = await createImageBitmap(file);
  try {
    if (bitmap.width !== bitmap.height) throw new Error("The frame must use a 1:1 square ratio.");
    const canvas = document.createElement("canvas");
    const sampleSize = Math.min(bitmap.width, 256);
    canvas.width = sampleSize;
    canvas.height = sampleSize;
    const context = canvas.getContext("2d", { willReadFrequently: true });
    if (!context) throw new Error("The frame could not be checked.");
    context.drawImage(bitmap, 0, 0, sampleSize, sampleSize);
    const pixels = context.getImageData(0, 0, sampleSize, sampleSize).data;
    let transparent = false;
    for (let index = 3; index < pixels.length; index += 4) {
      if (pixels[index] < 250) {
        transparent = true;
        break;
      }
    }
    if (!transparent) throw new Error("The PNG needs a transparent area for the visitor’s photo.");
    return { width: bitmap.width, height: bitmap.height };
  } finally {
    bitmap.close();
  }
}

function formatSize(size: number | null) {
  if (!size) return "External frame";
  return size < 1024 * 1024 ? `${Math.round(size / 1024)} KB` : `${(size / 1024 / 1024).toFixed(1)} MB`;
}

export function AdminFrameManager({
  storageConfigured,
  initialFrame,
}: {
  storageConfigured: boolean;
  initialFrame: FrameInfo | null;
}) {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [frame, setFrame] = useState(initialFrame);
  const [selected, setSelected] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [dimensions, setDimensions] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [busy, setBusy] = useState<"upload" | "delete" | "logout" | null>(null);

  const chooseFrame = async (file?: File) => {
    if (!file) return;
    setError(null);
    setSuccess(null);
    if (file.type !== "image/png") {
      setError("Choose a transparent PNG file.");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setError("The frame must be smaller than 8 MB.");
      return;
    }
    try {
      const details = await inspectPng(file);
      if (preview) URL.revokeObjectURL(preview);
      setSelected(file);
      setPreview(URL.createObjectURL(file));
      setDimensions(`${details.width} × ${details.height} px`);
    } catch (error) {
      setError(error instanceof Error ? error.message : "The frame could not be checked.");
    }
  };

  const upload = async () => {
    if (!selected) return;
    setBusy("upload");
    setError(null);
    setSuccess(null);
    try {
      const data = new FormData();
      data.set("frame", selected);
      const response = await fetch("/api/admin/frame", { method: "POST", body: data });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || "Upload failed.");
      setSelected(null);
      if (preview) URL.revokeObjectURL(preview);
      setPreview(null);
      setDimensions(null);
      setSuccess("The new frame is active for all visitors.");
      const refreshed = await fetch("/api/frame", { cache: "no-store" }).then((item) => item.json());
      setFrame({
        url: refreshed.frame.url,
        uploadedAt: refreshed.frame.uploadedAt,
        size: selected.size,
        managed: true,
      });
    } catch (error) {
      setError(error instanceof Error ? error.message : "Upload failed.");
    } finally {
      setBusy(null);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  const remove = async () => {
    if (!window.confirm("Remove the active frame? Visitors will not be able to create a framed photo until another frame is uploaded.")) return;
    setBusy("delete");
    setError(null);
    setSuccess(null);
    try {
      const response = await fetch("/api/admin/frame", { method: "DELETE" });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || "The frame could not be removed.");
      setFrame(null);
      setSuccess("The active frame has been removed.");
    } catch (error) {
      setError(error instanceof Error ? error.message : "The frame could not be removed.");
    } finally {
      setBusy(null);
    }
  };

  const logout = async () => {
    setBusy("logout");
    await fetch("/api/admin/logout", { method: "POST" });
    router.refresh();
  };

  return (
    <main className="admin-shell admin-dashboard">
      <header className="admin-header">
        <div>
          <p className="eyebrow">Private administration</p>
          <h1>Profile frame</h1>
        </div>
        <div className="admin-header-actions">
          <Link href="/" target="_blank" rel="noreferrer"><ExternalLink size={16} /> Open creator</Link>
          <button type="button" onClick={() => void logout()} disabled={busy === "logout"}>
            <LogOut size={16} /> Sign out
          </button>
        </div>
      </header>

      {!storageConfigured && (
        <div className="admin-warning" role="alert">
          <AlertTriangle size={19} />
          <span>Connect a Vercel Blob store and add its environment variables before uploading a frame.</span>
        </div>
      )}

      <div className="admin-grid">
        <section className="admin-panel">
          <div className="panel-heading">
            <span>Current frame</span>
            <small className={frame ? "status-live" : "status-empty"}>{frame ? "Active" : "Not set"}</small>
          </div>

          <div className="frame-preview checkerboard">
            {frame ? (
              <>
                {/* Dynamic storage URLs require a native image element. */}
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={frame.url} alt="Currently active profile frame" />
              </>
            ) : (
              <div className="no-frame"><ShieldCheck size={32} /><p>No active frame</p></div>
            )}
          </div>

          {frame && (
            <div className="frame-meta">
              <span><strong>Type</strong> Transparent PNG</span>
              <span><strong>Size</strong> {formatSize(frame.size)}</span>
              <span><strong>Updated</strong> {frame.uploadedAt ? new Date(frame.uploadedAt).toLocaleString() : "Configured externally"}</span>
            </div>
          )}

          {frame?.managed && (
            <button className="danger-button" type="button" onClick={() => void remove()} disabled={busy === "delete"}>
              {busy === "delete" ? <LoaderCircle className="spin" size={17} /> : <Trash2 size={17} />}
              Remove active frame
            </button>
          )}
        </section>

        <section className="admin-panel">
          <div className="panel-heading">
            <span>{frame ? "Replace frame" : "Upload frame"}</span>
            <small>Admin only</small>
          </div>

          <button
            className="admin-upload-area"
            type="button"
            disabled={!storageConfigured}
            onClick={() => inputRef.current?.click()}
          >
            {preview ? (
              <>
                {/* Local object URLs require a native image element. */}
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={preview} alt="New frame preview" />
              </>
            ) : <ImageUp size={31} />}
            <strong>{preview ? selected?.name : "Choose transparent PNG"}</strong>
            <span>{dimensions || "Square 1:1 ratio · Recommended 1080 × 1080 px · Max 8 MB"}</span>
          </button>
          <input
            ref={inputRef}
            className="visually-hidden"
            type="file"
            accept="image/png"
            onChange={(event) => void chooseFrame(event.target.files?.[0])}
          />

          {selected && (
            <div className="selected-actions">
              <button type="button" className="secondary-button" onClick={() => inputRef.current?.click()}>
                <RefreshCcw size={16} /> Choose another
              </button>
              <button type="button" className="admin-primary-button" onClick={() => void upload()} disabled={busy === "upload"}>
                {busy === "upload" ? <LoaderCircle className="spin" size={18} /> : <Check size={18} />}
                {busy === "upload" ? "Activating…" : "Upload and activate"}
              </button>
            </div>
          )}

          {error && <p className="form-error admin-message" role="alert">{error}</p>}
          {success && <p className="success-message admin-message" role="status"><Check size={17} /> {success}</p>}

          <div className="frame-guidance">
            <h2>Frame checklist</h2>
            <ul>
              <li>Use a transparent PNG with a square 1:1 ratio.</li>
              <li>Keep the central portrait area transparent.</li>
              <li>Place campaign graphics around the outer edges.</li>
              <li>Use 1080 × 1080 px or larger for a sharp download.</li>
            </ul>
          </div>
        </section>
      </div>
    </main>
  );
}
