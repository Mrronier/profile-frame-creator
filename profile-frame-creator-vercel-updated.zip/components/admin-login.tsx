"use client";

import { FormEvent, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, KeyRound, LoaderCircle, LockKeyhole } from "lucide-react";

export function AdminLogin({ configured }: { configured: boolean }) {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (event: FormEvent) => {
    event.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const response = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || "Sign-in failed.");
      router.refresh();
    } catch (error) {
      setError(error instanceof Error ? error.message : "Sign-in failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="admin-shell">
      <Link className="back-link" href="/"><ArrowLeft size={17} /> Back to creator</Link>
      <section className="login-card">
        <span className="admin-icon"><LockKeyhole size={27} /></span>
        <p className="eyebrow">Private administration</p>
        <h1>Frame management</h1>
        <p>Sign in to upload or replace the profile frame shown to visitors.</p>

        {!configured ? (
          <div className="admin-warning" role="alert">
            Add <code>ADMIN_PASSWORD</code> and <code>ADMIN_SESSION_SECRET</code> to your Vercel environment variables before signing in.
          </div>
        ) : (
          <form className="login-form" onSubmit={(event) => void submit(event)}>
            <label htmlFor="password">Admin password</label>
            <div className="password-field">
              <KeyRound size={18} aria-hidden="true" />
              <input
                id="password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="Enter your password"
                required
              />
            </div>
            {error && <p className="form-error" role="alert">{error}</p>}
            <button className="admin-primary-button" disabled={loading} type="submit">
              {loading ? <LoaderCircle className="spin" size={19} /> : <LockKeyhole size={18} />}
              {loading ? "Signing in…" : "Sign in securely"}
            </button>
          </form>
        )}
      </section>
    </main>
  );
}
